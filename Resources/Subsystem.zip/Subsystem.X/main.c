// PIC18F57Q43 Light Sensor Project
// Reads analog input on RA0, controls LED on RF0, outputs to UART

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/adc/adc.h"
#include <stdio.h>
#include <stdint.h>


#define DARK_THRESHOLD 520    

int main(void) {
    uint16_t adc_value;
    
   
    SYSTEM_Initialize();
    
  
    TRISFbits.TRISF0 = 0;   // Set RF0 as output
    LATFbits.LATF0 = 0;      // Start with LED off
    
    
    printf("\r\nPIC18F57Q43 Light Sensor Ready\r\n");
    printf("Threshold: %u\r\n\r\n", DARK_THRESHOLD);
    
    while(1) {
        // Read ADC from RA0 (ANA0 channel)
        adc_value = ADC_ChannelSelectAndConvert(ADC_CHANNEL_ANA0);
        
        
     // Check if it's dark and control LED on RF0
        if(adc_value < DARK_THRESHOLD) {
            // Light detected - turn LED OFF
            LATFbits.LATF0 = 0;
            printf("ADC: %4u - LIGHT - LED OFF\r\n", adc_value);
        } else {
            // Dark detected - turn LED ON
            LATFbits.LATF0 = 1;
            printf("ADC: %4u - DARK - LED ON\r\n", adc_value);
        }
        
        
        __delay_ms(500);
    }
    
    return 0;
}

